﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SkyMars lib
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using InterfaceLib;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //skymars lib remoting object
        InterfaceLib.IMsg iRemoting = null;
        StructMsg.Pwd _Pwd;
        StructMsg.SkyConn_ip_port R1;
        StructMsg.time _time;
        StructMsg.othercode _otherCode;
        StructMsg.feed_spindle _feedSpindle;
        StructMsg.position _position;
        StructMsg.information _information;

        public Form1()
        {
            InitializeComponent();         
        }


        /// <summary>
        /// 傳送訊息
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="tmpTcpClient"></param>
       
        public void SendingMessage(string msg, TcpClient tmpTcpClient)
        {
            NetworkStream ns = tmpTcpClient.GetStream();
            if (ns.CanWrite)
            {
                byte[] msgByte = Encoding.UTF8.GetBytes(msg);
                ns.Write(msgByte, 0, msgByte.Length);
            }
        }
        
        /// <summary>
        /// 接收訊息
        /// </summary>
        /// <param name="tmpTcpClient">TcpClient</param>
        /// <returns>接收到的訊息</returns>
        public string ReceiveMessage(TcpClient tmpTcpClient)
        {
            string receiveMsg = string.Empty;
            byte[] receiveBytes = new byte[tmpTcpClient.ReceiveBufferSize];
            int numberOfBytesRead = 0;
            NetworkStream ns = tmpTcpClient.GetStream();
            if (ns.CanRead)
            {
                do
                {
                    numberOfBytesRead = ns.Read(receiveBytes, 0, tmpTcpClient.ReceiveBufferSize);
                    receiveMsg += UTF8Encoding.UTF8.GetString(receiveBytes, 0, numberOfBytesRead);
                }
                while (numberOfBytesRead > 0) ;
            }              
            return receiveMsg;
        }

        private void RequestButton_Click(object sender, EventArgs e)
        {
            //宣告變數
            ResponseTimelabel.Text = "";
            int tick1 = 0, tick2 = 0;//計算時間
            // 建立 TCP/IP物件
            TcpClient tcpClient = new TcpClient();
            try
            {
                //先建立IPAddress物件,IP為欲連線機之IP
                IPAddress ipAddress = IPAddress.Parse(txtIp.Text);
                //建立IPEndPoint
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddress,
                int.Parse(txtPort.Text));
                //透過TCP建立
                tcpClient.Connect(ipEndPoint);             
                //連線成功
                if (tcpClient.Connected)
                {
                    //開始時間
                    tick1 = Environment.TickCount;
                    //整理資料
                    if (SendingTextBox.Text[SendingTextBox.Text.Length - 1] == '\n')
                        SendingTextBox.Text = SendingTextBox.Text.Substring(
                        0, SendingTextBox.Text.Length - 1);

                    //傳送xml資料
                    SendingMessage(SendingTextBox.Text, tcpClient);

                    //接收回傳資料
                    string RecvString = ReceiveMessage(tcpClient);
                    ReceivedTextBox.Text = RecvString;

                    //計算回傳時間差
                    tick2 = Environment.TickCount - tick1;
                    ResponseTimelabel.Text = tick2.ToString();
                }
                else
                    ReceivedTextBox.Text = "連線失敗!";
            }
            catch(Exception ex)
            {
                ReceivedTextBox.Text = ex.Message;
            }
        }

        /// <summary>
        /// 取得CycleTime
        /// </summary>
        public void GetCycleTime()
        {
            short ret = iRemoting.GET_time(_Pwd, ref _time);
            //response = 0 
            if(ret == 0)
            {
                 ReceivedTextBox.Text = _time.Cycle[0].ToString() + " : " + _time.Cycle[1].ToString() + " : " + _time.Cycle[2].ToString() + "\r\n";
            }
        }


        /// <summary>
        /// 取得F S Code
        /// </summary>
        public void GetFCodeSCode()
        {
            var ret = iRemoting.GET_othercode(_Pwd, ref _otherCode);
            if(ret == 0)
            {
                ReceivedTextBox.AppendText(_otherCode.FCode + " and " + _otherCode.SCode + "\r\n");
            }
        }

        /// <summary>
        /// 取得實際Feed Spindle
        /// </summary>
        public void GetActFeedActSpindle()
        {
            var ret = iRemoting.GET_feed_spindle(_Pwd, ref _feedSpindle);
            if(ret == 0)
            {
                ReceivedTextBox.AppendText(_feedSpindle.ActFeed + " and " + _feedSpindle.ActSpindle + "\r\n");
            }
        }

        /// <summary>
        /// 取得機械座標
        /// </summary>
        public void GetMachinePosition()
        {
            var ret = iRemoting.GET_information(_Pwd, ref _information);
            if(ret == 0)
            {
                ret = iRemoting.GET_position(_Pwd, ref _position);
                if (ret == 0)
                {
                    for(int i = 0; i < _information.AxisName.Length; i++)
                    {
                        ReceivedTextBox.AppendText($@"{_information.AxisName[i]}軸: 座標 = {_position.Mach[i]}" + "\r\n");
                    }
                }
            }
            
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            if (ChannelServices.RegisteredChannels.Length == 0)
                ChannelServices.RegisterChannel(new TcpChannel(), false);
            iRemoting = (IMsg)Activator.GetObject(typeof(IMsg), "tcp://127.0.0.1:9501/RemoteObjectURI9501");
            _Pwd.ConnectionKey = "123";

        }


        private void button1_Click(object sender, EventArgs e)
        {
            GetCycleTime();
            GetFCodeSCode();
            GetActFeedActSpindle();
            GetMachinePosition();
        }
    }
}
