﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using InterfaceLib;
using System.IO;

namespace Sky1
{
    public partial class Form1 : Form
    {
        InterfaceLib.IMsg _remoting;
        StructMsg.Pwd _pwd;
        StructMsg.SkyConn_status _skyconn_status;
        StructMsg.time _time;
        StructMsg.SkyNc_filename _skync_filename;
        StructMsg.feed_spindle _feed_spindle;
        StructMsg.position _position;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ChannelServices.RegisteredChannels.Length == 0)
            {
                ChannelServices.RegisterChannel(new TcpChannel(), false);
            }
            _remoting = (IMsg)Activator.GetObject(typeof(IMsg), "tcp://localhost:9501/RemoteObjectURI9501");
            _pwd.ConnectionKey = "pmc";
            _pwd.WritePwd = "pmc";
            short ret = _remoting.SKY_conn_status(_pwd, ref _skyconn_status);
            if (ret == 0)
            {
                textBox8.Text = "連線成功!";
                label8.BackColor = Color.Green;
                button3.Enabled = true;
            }
            else
            {
                textBox8.Text = "錯誤代碼 : "+ret.ToString();
                label8.BackColor = Color.Red;
                button3.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            GetCycleTime();
            GetNcFileName();
            GetFeedSpindle();
            GetPosition();
            string fileName = "C:\\cnc.csv";
            string content = textBox1.Text.ToString() + "," + textBox3.Text.ToString() + "," + textBox4.Text.ToString() + "," + textBox5.Text.ToString() + "," + textBox6.Text.ToString() + "\r\n";
            System.IO.File.AppendAllText(fileName, content);
        }

        public void GetCycleTime()
        {
            short ret = _remoting.GET_time(_pwd, ref _time);
            if (ret == 0)
            {
                int second = _time.Cycle[1] * 60 + _time.Cycle[2];
                textBox1.Text = second.ToString();
            }
        }

        public void GetNcFileName()
        {
            short ret = _remoting.SKY_nc_filename(_pwd, ref _skync_filename);
            if (ret == 0)
            {
                textBox2.Text = _skync_filename.MainProg[0];
            }
        }

        public void GetFeedSpindle()
        {
            short ret = _remoting.GET_feed_spindle(_pwd, ref _feed_spindle);
            if (ret == 0)
            {
                textBox3.Text = _feed_spindle.ActFeed.ToString();
                textBox4.Text = _feed_spindle.ActSpindle.ToString();
            }
        }

        public void GetPosition()
        {
            short ret = _remoting.GET_position(_pwd, ref _position);
            if (ret == 0)
            {
                textBox5.Text = _position.Mach[0].ToString();
                textBox6.Text = _position.Mach[1].ToString();
                textBox7.Text = _position.Mach[2].ToString();
            }
        }
    }
}
