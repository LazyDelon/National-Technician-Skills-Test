﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using InterfaceLib;
using System.IO;

namespace Sky1
{
    public partial class Form1 : Form
    {
        InterfaceLib.IMsg _remoting;
        StructMsg.Pwd _pwd;
        StructMsg.SkyConn_status _skyconn_status;
        StructMsg.time _time;
        StructMsg.status _status;
        StructMsg.spindle_speed _spindle_speed;
        StructMsg.spindle_load _spindle_load;
        StructMsg.feed_spindle _feed_spindle;
        StructMsg.position _position;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ChannelServices.RegisteredChannels.Length == 0)
            {
                ChannelServices.RegisterChannel(new TcpChannel(), false);
            }
            _remoting = (IMsg)Activator.GetObject(typeof(IMsg), "tcp://localhost:9501/RemoteObjectURI9501");
            _pwd.ConnectionKey = "pmc";
            _pwd.WritePwd = "pmc";
            short ret = _remoting.SKY_conn_status(_pwd, ref _skyconn_status);
            if (ret == 0)
            {
                textBox8.Text = "連線成功!";
                label8.BackColor = Color.Green;
                button3.Enabled = true;
            }
            else
            {
                textBox8.Text = "錯誤代碼 : "+ret.ToString();
                label8.BackColor = Color.Red;
                button3.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            GetCycleTime();
            GetStatus();
            GetSpindleSpeed();
            GetSpindleLoad();
            GetFeedOverride();
            GetPosition();
            string fileName = "C:\\cnc.csv";
            string content = textBox1.Text.ToString() + "," + textBox3.Text.ToString() + "," + textBox4.Text.ToString() + "," + textBox5.Text.ToString() + "," + textBox6.Text.ToString() + "," + textBox7.Text.ToString() + "\r\n";
            System.IO.File.AppendAllText(fileName, content);
        }

        public void GetCycleTime()
        {
            short ret = _remoting.GET_time(_pwd, ref _time);
            if (ret == 0)
            {
                int second = _time.Cycle[1] * 60 + _time.Cycle[2];
                textBox1.Text = second.ToString();
            }
        }

        public void GetStatus()
        {
            short ret = _remoting.GET_status(_pwd, ref _status);
            if (ret == 0)
            {
                textBox2.Text = _status.Status.ToString();
            }
        }

        public void GetSpindleSpeed()
        {
            short ret = _remoting.GET_spindle_speed(_pwd, ref _spindle_speed);
            if (ret == 0)
            {
                textBox3.Text = _spindle_speed.SpSpeed.ToString();
            }
        }

        public void GetSpindleLoad()
        {
            short ret = _remoting.GET_spindle_load(_pwd, ref _spindle_load);
            if (ret == 0)
            {
                textBox4.Text = _spindle_load.SpLoad.ToString();
            }
        }

        public void GetFeedOverride()
        {
            short ret = _remoting.GET_feed_spindle(_pwd, ref _feed_spindle);
            if (ret == 0)
            {
                textBox5.Text = _feed_spindle.OvFeed.ToString();
            }
        }

        public void GetPosition()
        {
            short ret = _remoting.GET_position(_pwd, ref _position);
            if (ret == 0)
            {
                textBox6.Text = _position.Rel[0].ToString();
                textBox7.Text = _position.Rel[1].ToString();
            }
        }

    }
}
